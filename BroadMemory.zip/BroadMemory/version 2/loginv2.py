import tkinter as tk
from tkinter import PhotoImage, Label
import sqlite3 
import subprocess
import customtkinter

# Set appearance mode to 'light'
customtkinter.set_appearance_mode('light')

# Connect to the SQLite database or create if not exists
conn = sqlite3.connect('user_score.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT)''')
conn.commit()
conn.close  # You should call the close function here by using 'conn.close()'

# Function to go back to the login screen
def back_to_login():
    subprocess.call(['python', r"version 2\createv2.py"])
    root.destroy()

# Function to run the game
def run_game():
    subprocess.call(['python', r"version 2\gamev2.py"])
    root.destroy()
    
# Function to hide the message label
def hide_label():
    message_label.grid_forget()

# Function to register a user
def register_user():
    global message_label

    username = username_entry.get()
    password = password_entry.get()

    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE username=? AND password=?', (username, password))
    user = cursor.fetchone()

    if user:
        message_label = customtkinter.CTkLabel(root, text='Login Successful')
        message_label.grid(column=0, row=5, columnspan=2, pady=8)

        root.after(1000, hide_label)
        root.after(1000, run_game)
    else:
        message_label = customtkinter.CTkLabel(root, text='Invalid Username or Password')
        message_label.grid(column=0, row=5, columnspan=2, pady=8)

        root.after(1000, hide_label)

    conn.close()

# Create the main GUI window
root = tk.Tk()
root.title("Login")

# Load and display the logo image
logo_image = PhotoImage(file=r"images\origin_logo.png")
logo_label = Label(root, image=logo_image, anchor='center')
logo_label.grid(column=0, row=0, columnspan=2, pady=15)

# Username entry field and label
username_label = tk.Label(root, text="Username:", foreground="blue", font=('arial', 12, 'bold'))
username_label.grid(column=0, row=1, pady=8)
username_entry = customtkinter.CTkEntry(root)
username_entry.grid(column=1, row=1, pady=8)

# Password entry field and label
password_label = tk.Label(root, text="Password:", foreground="blue", font=('arial', 12, 'bold'))
password_label.grid(column=0, row=2, pady=8)
password_entry = customtkinter.CTkEntry(root, show="*")
password_entry.grid(column=1, row=2, pady=8)

# Login button
login_button = customtkinter.CTkButton(root, text="Sign in", command=register_user, border_width=2, border_color="green")
login_button.grid(column=0, row=3, columnspan=2, pady=15)

# Create account button
create_button = customtkinter.CTkButton(root, text="Create an account", command=back_to_login, border_width=3, border_color="red", width=200)
create_button.grid(column=0, row=4, columnspan=2, pady=8)

# Start the main event loop
root.mainloop()
