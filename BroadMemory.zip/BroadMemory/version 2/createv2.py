import tkinter as tk
import subprocess
import sqlite3
import customtkinter

# Set the appearance mode to 'light' using customtkinter library
customtkinter.set_appearance_mode('light')

# Function to hide a label
def hide_label():
    message_label.grid_forget()

# Function to open the login page using a subprocess and close the current window
def login_page():
    subprocess.Popen(['python', r"version 2\loginv2.py"])
    root.destroy()

# Function to register a new user
def register_user():
    global message_label
    # Get the entered username, password, and confirm password
    username = username_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()

    # Connect to the SQLite database
    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

    # Check if the username already exists
    cursor.execute('SELECT * FROM users WHERE username=?', (username, ))
    existing_user = cursor.fetchone()

    # If username already exists, show a message
    if existing_user:
        message_label = customtkinter.CTkLabel(root, text='Username already Exists')
        message_label.grid(row=7, columnspan=2, pady=20)
        root.after(500, hide_label)
        conn.close()

    # If passwords don't match, show a message
    elif password != confirm_password:
        message_label = customtkinter.CTkLabel(root, text="Passwords don't match.")
        message_label.grid(row=7, columnspan=2, pady=20)
        root.after(500, hide_label)

    # If everything is valid, insert the new user into the database and show a success message
    else:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        message_label = customtkinter.CTkLabel(root, text='Registered Successfully')
        message_label.grid(row=7, columnspan=2, pady=20)
        root.after(500, hide_label)
        login_page()  # Redirect to login page
    conn.close()

# Create the main Tkinter window
root = tk.Tk()
root.title('Create Account')

# Load logo and account images
logo_image = tk.PhotoImage(file=r'images\logomemorygame.png')
account_image = tk.PhotoImage(file=r'images\creatacc.png')

# Display logo and account images
logo_label = tk.Label(root, image=logo_image)
logo_label.grid(row=0, columnspan=2, pady=10)

account_label = tk.Label(root, image=account_image)
account_label.grid(row=1, columnspan=2, pady=10)

# Button for users who are already registered
already_registered_button = customtkinter.CTkButton(root, text='Already Registered?!', command=login_page, width=200)
already_registered_button.grid(row=2, columnspan=2, pady=20)

# Entry fields for username, password, and confirm password
username_entry = customtkinter.CTkEntry(root, justify='center')
username_entry.insert(0, 'Username')
username_entry.grid(row=3, columnspan=2, pady=5)

password_entry = customtkinter.CTkEntry(root, justify='center', show='*')
password_entry.insert(0, 'Password')
password_entry.grid(row=4, columnspan=2, pady=5)

confirm_password_entry = customtkinter.CTkEntry(root, justify='center', show='*')
confirm_password_entry.insert(0, 'Confirm Password')
confirm_password_entry.grid(row=5, columnspan=2, pady=5)

# Button to register a new user
register_button = customtkinter.CTkButton(root, text='Register', command=register_user)
register_button.grid(row=6, columnspan=2, pady=9)

# Start the Tkinter event loop
root.mainloop()
