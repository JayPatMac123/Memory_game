import tkinter as tk
import subprocess
import sqlite3

def hide_label():
    message_label.pack_forget()

def login_page():
    subprocess.Popen(['python',r"version 1\loginv1.py"])
    root.destroy()

def register_user():
    global message_label
    username = username_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()

    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

  

    cursor.execute('SELECT * FROM users WHERE username=?', (username, ))
    existing_user = cursor.fetchone()
    if existing_user:

        

        message_label = tk.Label(root, text='Username already Exists')
        message_label.pack(pady=20)
        root.after(1000, hide_label)

        conn.close()
    elif password != confirm_password:

      

        message_label = tk.Label(root, text="Passwords don't match.")
        message_label.pack(pady=20)
        root.after(1000, hide_label)
        
    else:

       

        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)'
                       , (username, password))
        conn.commit()

        message_label = tk.Label(root, text='Registered Successfully')
        message_label.pack(pady=20)
        root.after(500, hide_label) 
        
    conn.close()
       


root = tk.Tk()
root.title('Create Account')

logo_image = tk.PhotoImage(file=r'images\logomemorygame.png')


logo_label = tk.Label(root, image=logo_image)
logo_label.pack(pady=10)


already_registered_button = tk.Button(root, text='If you are already have an account, login through here!', command=login_page)
already_registered_button.pack(pady=20)

username_entry = tk.Entry(root, justify='center')
username_entry.insert(0, 'Username')
username_entry.pack(pady=5)

password_entry = tk.Entry(root, justify='center', show='*')
password_entry.insert(0, 'Password')
password_entry.pack(pady=5)

confirm_password_entry = tk.Entry(root, justify='center', show='*')
confirm_password_entry.insert(0, 'Confirm Password')
confirm_password_entry.pack(pady=5)

register_button = tk.Button(root, text='Register', command=register_user)
register_button.pack(pady=20)

root.mainloop()
