import customtkinter
from tkinter import Button, messagebox
import tkinter as tk
import random
from functools import partial



customtkinter.set_appearance_mode('system')


def self_destroy():
    root.destroy()

def play_game():
   

    global play_button, quit_button




    play_button = tk.Button(root, text="Play", command=show_difficulty_options)
    play_button.grid(column=0,row=0, pady=20, padx=20)

    quit_button = tk.Button(root, text="Quit", command=self_destroy)
    quit_button.grid(column=1,row=0, pady=20, padx=20)

  


    

def show_difficulty_options():  
    global play_button, quit_button, easy_difficulty_label, hard_difficulty_label, difficulty_label
    play_button.grid_forget()
    quit_button.grid_forget()
    
    difficulty_label = tk.Label(root, text="Select Difficulty Option:")
    difficulty_label.grid(column=0,row=0, pady=20, padx=20, columnspan=2)

    easy_difficulty_label = tk.Button(root, text="Easy",command=partial(start_game, 5))
    easy_difficulty_label.grid(column=0,row=1, pady=20, padx=20)

    hard_difficulty_label = tk.Button(root, text="Hard",command=partial(start_game, 7))
    hard_difficulty_label.grid(column=1,row=1, pady=20, padx=20)

    
def start_game(grid_size):
    
    global difficulty_label, score,  seconds, selected, time_operate, score_label, timer_label, board_frame, new_game_button, main_menus_button, logo_label, score_time_Label, time_operate, size_grid


    easy_difficulty_label.grid_forget()
    hard_difficulty_label.grid_forget()
    difficulty_label.grid_forget()

    score = 0
    seconds = 0
    
    selected = []

   

    score_label = tk.Label(root,text='Score: 0', justify="center")
    score_label.grid(column = 0, row=0 ,pady = 10, padx=10)

    timer_label = tk.Label(root,text='Time: 0s', justify="center")

    timer_label.grid(column = 0, row=1 ,pady = 10, padx=10)
    board_frame = tk.Frame(root)
    board_frame.grid(row=3, column=0, columnspan=grid_size, pady=10)

    
    new_game_label = Button(root, text="New Game",command=partial(new_game,grid_size))
    
    new_game_label.grid(column = 0, row=4 ,pady = 10, padx=10)




def new_game(grid_size):
    global score, seconds, selected, time_operate, score_label, timer_label, board_frame, cards, card_values,   card_button, game_ender
   
    game_ender = 0
    score = 0
    seconds = 0
    time_operate = False
    selected = []


    score_label.config(text='Score: {}'.format(score))
    timer_label.config(text='Time: {}s'.format(seconds))

  



    board_frame = tk.Frame(root)
    board_frame.grid(row=3, column=0, columnspan=grid_size)

    cards = []  
   

    symbols = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',]
    card_values = symbols[:49 // 2] * 2
    random.shuffle(card_values)

   

    


    for i in range(grid_size):
        for j in range(grid_size):
         card_button = tk.Button(board_frame,text='',width=3,height=1,relief='raised',command=partial(card_switch, i, j, grid_size))
         card_button.grid(row=i, column=j, padx=5, pady=5)
         cards.append(card_button)








def card_switch(i, j, grid_size):

    global time_operate, score, selected, card_values, cards, card_button, main_menus2_button, game_ender, seconds

    if not time_operate:
        time_operate = True
        start_timer()

  

    if (i, j) in selected:
        return

   

    card_button = cards[i * grid_size + j]
    card_button.config(text=str(card_values[i * grid_size + j]))

    

    selected.append((i, j))

  

    if len(selected) == 2:
        (box1_i, box1_j) = selected[0]
        (box2_i, box2_j) = selected[1]
        
        if card_values[box1_i * grid_size + box1_j] == card_values[box2_i * grid_size + box2_j]:
            
    

            score += 100
            game_ender += 1
            score_label.configure(text='Score: {}'.format(score))
            
            selected = []

            if game_ender / 2 == (grid_size+1):
                end_game() 
               
        else:
            root.after(1000, reset_selection,grid_size)


 







def reset_selection(grid_size):
    

    global selected, cards

    (box1_i, box1_j) = selected[0]
    (box2_i, box2_j) = selected[1]

   

    cards[box1_i * grid_size + box1_j].configure(text='')
    cards[box2_i * grid_size + box2_j].configure(text='')

    selected = []  


def start_timer():
    

    global seconds, timer_label, time_operate, main_menus2_button

    seconds += 1
    timer_label.configure(text='Time: {}s'.format(seconds))
    timer_label.after(1000, start_timer)


def end_game():
  

    global time_operate, seconds, current_user

    time_operate = False

    messagebox.showinfo('Congratulations!',
                        'You won in {} seconds'.format(seconds))

    play_game()

        

if __name__ == "__main__":
   
    root = tk.Tk()
 

    play_game()
  
   
    root.mainloop()

