import tkinter as tk
from tkinter import PhotoImage, Label
import sqlite3 
import subprocess



conn = sqlite3.connect('user_score.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT)''')
conn.commit()
conn.close

def run_game():
    subprocess.call(['python', r"version 1\gamev1.py"])
    root.destroy()
    
def hide_label():
    message_label.pack_forget()


def register_user():
    global message_label

    username = username_entry.get()
    password = password_entry.get()



    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE username=? AND password=?'
                   , (username, password))
    user = cursor.fetchone()

    if user:
        message_label = tk.Label(root, text='Login Successful')
        message_label.pack(pady=5)

        root.after(500, hide_label)

        run_game()
    else:
        message_label = tk.Label(root, text='Invalid Username or Password')
        message_label.pack(pady=5)

        root.after(500, hide_label)

    conn.close()



root = tk.Tk()
root.title("Login")


logo_image = PhotoImage(file=r"images\origin_logo.png")
logo_label = Label(root, image=logo_image,anchor='center')
logo_label.pack(pady=5)



username_label = tk.Label(root, text="Username:")
username_label.pack(pady=5)
username_entry = tk.Entry(root)
username_entry.pack(pady=5)

password_label = tk.Label(root, text="Password:")
password_label.pack(pady=5)
password_entry = tk.Entry(root, show="*")
password_entry.pack(pady=5)


login_button = tk.Button(root, text="Sign in", command=register_user,  width=10, height=2)
login_button.pack(pady=5)





root.mainloop()
