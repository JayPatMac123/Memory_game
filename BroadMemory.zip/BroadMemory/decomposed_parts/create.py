import tkinter as tk


def hide_label(label):
    label.grid_remove()


def register_user():
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()

    
    if password != confirm_password:
        message_label.config(text='Passwords do not match', foreground='red')
        root.after(1000,hide_label)
   
    else:
       
        message_label.config(text='Registered Successfully', foreground='green')
       


root = tk.Tk()
root.title('Create Account')

logo_image = tk.PhotoImage(file=r'images\logomemorygame.png')


logo_label = tk.Label(root, image=logo_image)
logo_label.pack(pady=10)


username_entry = tk.Entry(root, justify='center')
username_entry.insert(0, 'Username')
username_entry.pack(pady=5)

password_entry = tk.Entry(root, justify='center')
password_entry.insert(0, 'Password')
password_entry.pack(pady=5)

confirm_password_entry = tk.Entry(root, justify='center')
confirm_password_entry.insert(0, 'Confirm Password')
confirm_password_entry.pack(pady=5)

message_label = tk.Label(root, text='')
message_label.pack(pady=5)

register_button = tk.Button(root, text='Register', command=register_user)
register_button.pack(pady=20)

root.mainloop()
