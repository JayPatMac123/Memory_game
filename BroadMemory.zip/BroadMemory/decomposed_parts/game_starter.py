
import tkinter as tk
import subprocess








def play_game():
   

    global play_button, quit_button




    play_button = tk.Button(root, text="Play", command=show_difficulty_options)
    play_button.grid(column=0,row=0, pady=20, padx=20)

    quit_button = tk.Button(root, text="Quit")
    quit_button.grid(column=1,row=0, pady=20, padx=20)

  

def easy_game():
    root.destroy()
    subprocess.Popen(['python', r'decomposed_parts\easy.py'])

def hard_game():
    root.destroy()
    subprocess.Popen(['python', r'decomposed_parts\hard.py'])
    

def show_difficulty_options():  
    global play_button, quit_button, easy_difficulty_label, hard_difficulty_label
    play_button.grid_forget()
    quit_button.grid_forget()
    
    
    easy_difficulty_label = tk.Button(root, text="Easy ",command=easy_game)
    easy_difficulty_label.grid(column=0,row=0, pady=20, padx=20)

    hard_difficulty_label = tk.Button(root, text="Hard",command=hard_game)
    hard_difficulty_label.grid(column=1,row=0, pady=20, padx=20)

    






        

if __name__ == "__main__":
   
    root = tk.Tk()
 

    play_game()
  
   
    root.mainloop()

