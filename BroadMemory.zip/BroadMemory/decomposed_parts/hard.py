from tkinter import Button, messagebox
import tkinter as tk
import random
from functools import partial


def start_game():
    
    global difficulty_label, score,  seconds, selected, time_operate, score_label, timer_label, board_frame, new_game_button, main_menus_button, logo_label, score_time_Label, time_operate, size_grid

    

    

  
    score = 0
    seconds = 0
    
    selected = []

   

    score_label = tk.Label(root,text='Score: 0', justify="center")
    score_label.grid(column = 0, row=0 ,pady = 10, padx=10)

    timer_label = tk.Label(root,text='Time: 0s', justify="center")

    timer_label.grid(column = 0, row=1 ,pady = 10, padx=10)
    board_frame = tk.Frame(root)
    board_frame.grid(row=3, column=0, columnspan=7, pady=10)

    
    new_game_label = Button(root, text="New Game",command=new_game)
    
    new_game_label.grid(column = 0, row=4 ,pady = 10, padx=10)




def new_game():
    global score, seconds, selected, time_operate, score_label, timer_label, board_frame, cards, card_values,   card_button, game_ender, matched_card
  

    game_ender = 0
    score = 0
    seconds = 0
    time_operate = False
    selected = []

    score_label.config(text='Score: {}'.format(score))
    timer_label.config(text='Time: {}s'.format(seconds))

  



    board_frame = tk.Frame(root)
    board_frame.grid(row=3, column=0, columnspan=7)

    cards = []  
   

    symbols = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',]
    card_values = symbols[:49 // 2] * 2
    random.shuffle(card_values)

    

    for i in range(7):
        for j in range(7):
         card_button = tk.Button(board_frame,text='',width=3,height=2,relief='raised',command=partial(card_switch, i, j))
         card_button.grid(row=i, column=j, padx=5, pady=5)
         cards.append(card_button)







def card_switch(i, j):

    global time_operate, score, selected, card_values, cards, card_button, main_menus2_button, game_ender, seconds

   

    if not time_operate:
        time_operate = True
        start_timer()



    if (i, j) in selected :
        return

    

    card_button = cards[i * 7 + j]
    card_button.config(text=str(card_values[i * 7 + j]))



    selected.append((i, j))



    if len(selected) == 2:
        (box1_i, box1_j) = selected[0]
        (box2_i, box2_j) = selected[1]

        if card_values[box1_i * 7 + box1_j] == card_values[box2_i * 7 + box2_j]:

         

            score += 100
            game_ender += 1
            score_label.configure(text='Score: {}'.format(score))
           
            selected = []

            if game_ender / 2 == (8):
                end_game() 
        else:


            root.after(1000, reset_selection)


 







def reset_selection():
    

    global selected, cards

    (box1_i, box1_j) = selected[0]
    (box2_i, box2_j) = selected[1]



    cards[box1_i * 7 + box1_j].configure(text='')
    cards[box2_i * 7 + box2_j].configure(text='')

    selected = []  


def start_timer():
    

    global seconds, timer_label, time_operate, main_menus2_button

    seconds += 1
    timer_label.configure(text='Time: {}s'.format(seconds))
    timer_label.after(1000, start_timer)


def end_game():
  

    global time_operate, seconds, current_user

    time_operate = False

    messagebox.showinfo('Congratulations!',
                        'You won in {} seconds'.format(seconds))
    
if __name__ == "__main__":
   
    root = tk.Tk()
    start_game()
   
    root.mainloop()
