import tkinter as tk
from tkinter import PhotoImage, Label


# Function to check user credentials
def login():
        message_label.config(text="Login Successful", foreground="green")
      



# Create the main root window
root = tk.Tk()
root.title("Login")


logo_image = PhotoImage(file=r"images\origin_logo.png")
logo_label = Label(root, image=logo_image,anchor='center')
logo_label.grid(row=0, column=0, padx=10, pady=10, columnspan=2)


# Username label and entry
username_label = tk.Label(root, text="Username:")
username_label.grid(row=1, column=0, pady=5)
username_entry = tk.Entry(root)
username_entry.grid(row=1, column=1, pady=5)

# Password label and entry
password_label = tk.Label(root, text="Password:")
password_label.grid(row=2, column=0, pady=5)
password_entry = tk.Entry(root)
password_entry.grid(row=2, column=1, pady=5)

# "Sign in" button
login_button = tk.Button(root, text="Sign in", command=login)
login_button.grid(row=3, column=0, columnspan=2, pady=10)

# Error message label
message_label = tk.Label(root, text="")
message_label.grid(row=4, column=0, columnspan=2)

# Start the main event loop
root.mainloop()
