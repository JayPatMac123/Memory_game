#!/usr/bin/python
# -*- coding: utf-8 -*-
''' This page is where user can create thier own accounts to save their score they can acheieve '''

import subprocess
from tkinter import Tk, PhotoImage, Label, Frame
import tkinter as tk
from tkinter import ttk
import customtkinter
from PIL import Image, ImageTk
import sqlite3
import re

# Creating the main root window

root = Tk()
root.option_add('*Font', 'Georgia')
root.geometry('330x650')
root.resizable(False, False)
root.configure(background='white')
root.title('Create Account')


# Function to hide the message label after displaying it

def hide_label():
    ''' This hides the label for telling them, if thier information is incorrect '''

    global message_label
    message_label.grid_remove()


# Function to open the login.py file when the "Already registered? Log in here!" label is clicked

def open_file(event):
    ''' iF the user is already registered (have an account already) they will sent to the login page '''

    subprocess.Popen(['python', r"login.py"])
    root.destroy()


# Function to run the login.py file and destroy the current window

def run_another_file():
    ''' IF the information they have created is valid they
      will be sent to the login page with thier information saved '''

    subprocess.Popen(['python', r"login.py"])
    root.destroy()


# Function to register a new user

def register_user():
    ''' This checks if the information they have entered is valid when creating a new account '''

    global message_label

    # Retrieving the username and passwords from the entry widgets

    username = username_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()

    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

    # Checking if the username already exists in the database

    cursor.execute('SELECT * FROM users WHERE username=?', (username, ))
    existing_user = cursor.fetchone()
    if existing_user:

        # Displaying an error message if the username already exists

        message_label = ttk.Label(root, text='Username already Exists',
                                  foreground='red', background='white',
                                  font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
        conn.close()
    elif not 3 <= len(username) <= 15:

        # Checking if the username length is valid

        message_label = ttk.Label(root,
                                  text='Username must be between\n 3 and 15 characters.'
                                  , foreground='red', background='white'
                                  , font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
    elif not 4 <= len(password) <= 20:

        # Checking if the password length is valid

        message_label = ttk.Label(root,
                                  text='Password must be between\n  4 and 20 characters.'
                                  , foreground='red', background='white'
                                  , font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
    elif not re.search(r'[A-Z]', password):

        # Checking if the password contains at least 1 capital letter

        message_label = ttk.Label(root,
                                  text='Password must contain at\n  least 1 capital letter.'
                                  , foreground='red', background='white'
                                  , font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
    elif not re.search(r'\d', password):

        # Checking if the password contains at least 1 numeric character

        message_label = ttk.Label(root,
                                  text='Password must contain at\n least 1 numeric character.'
                                  , foreground='red', background='white'
                                  , font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
    elif password != confirm_password:

        # Checking if the passwords match

        message_label = ttk.Label(root, text="Passwords don't match.",
                                  foreground='red', background='white',
                                  font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)
    else:

        # Inserting the new user into the database

        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)'
                       , (username, password))
        conn.commit()

        # Displaying success message and run the login.py file

        message_label = ttk.Label(root, text='Registered Successfully',
                                  foreground='green', background='white'
                                  , font=('Arial', 12, 'bold'))
        message_label.grid(row=8, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(1000, run_another_file)

    conn.close()


# Functions to handle the entry widgets' focus events

def on_username_entry_click(event):
    if username_entry.get() == 'Username':
        username_entry.delete(0, 'end')
        username_entry.config(fg='#000000')


def on_username_focus_out(event):
    if username_entry.get() == '':
        username_entry.insert(0, 'Username')
        username_entry.config(fg='#000000')


def on_password_entry_click(event):
    if password_entry.get() == 'Password':
        password_entry.delete(0, 'end')
        password_entry.config(fg='#000000')


def on_password_focus_out(event):
    if password_entry.get() == '':
        password_entry.insert(0, 'Password')
        password_entry.config(fg='#000000')


def on_confirm_password_entry_click(event):
    if confirm_password_entry.get() == 'Password':
        confirm_password_entry.delete(0, 'end')
        confirm_password_entry.config(fg='#000000')


def on_confirm_password_focus_out(event):
    if confirm_password_entry.get() == '':
        confirm_password_entry.insert(0, 'Password')
        confirm_password_entry.config(fg='#000000')


# Loading images for logo and account icons

logo_image = PhotoImage(file=r"images\logomemorygame.png")
account = PhotoImage(file=r"images\creatacc.png")

# Creating and place widgets on the root window

logo_label = Label(root, image=logo_image, background='white')
logo_label.grid(row=0, column=0, padx=10, pady=10, columnspan=2)

account_label = Label(root, image=account, background='white')
account_label.grid(row=1, column=0, padx=10, pady=10, columnspan=2)

clickhere = ttk.Label(
    root,
    text='Already registered? Log in here!',
    font=customtkinter.CTkFont(size=20, weight='bold',
                               family='Century Gothic'),
    foreground='#185cac',
    background='white',
    cursor='hand2',
    )
clickhere.grid(row=2, column=0, padx=10, pady=35, columnspan=2)
clickhere.bind('<Button-1>', open_file)

# Creating entry widgets for username, password, and confirm password

username_entry = tk.Entry(
    root,
    width=25,
    relief='flat',
    font=('Century Gothic', 13, 'bold'),
    fg='#000000',
    bg='white',
    justify='center',
    )
username_entry.grid(row=3, column=0, padx=10, pady=5, columnspan=2)
username_entry.insert(0, 'Username')
username_entry.bind('<FocusIn>', on_username_entry_click)
username_entry.bind('<FocusOut>', on_username_focus_out)

password_entry = tk.Entry(
    root,
    width=25,
    relief='flat',
    font=('Century Gothic', 13, 'bold'),
    fg='#000000',
    bg='white',
    justify='center',
    show='*',
    )
password_entry.grid(row=5, column=0, padx=10, pady=5, columnspan=2)
password_entry.insert(0, 'Password')
password_entry.bind('<FocusIn>', on_password_entry_click)
password_entry.bind('<FocusOut>', on_password_focus_out)

confirm_password_entry = tk.Entry(
    root,
    width=25,
    relief='flat',
    font=('Century Gothic', 13, 'bold'),
    fg='#000000',
    bg='white',
    justify='center',
    show='*',
    )
confirm_password_entry.grid(row=6, column=0, padx=10, pady=5,
                            columnspan=2)
confirm_password_entry.insert(0, 'Password')
confirm_password_entry.bind('<FocusIn>',
                            on_confirm_password_entry_click)
confirm_password_entry.bind('<FocusOut>', on_confirm_password_focus_out)

# Creating the register button

login_button = customtkinter.CTkButton(root, text='Login',
        command=register_user, font=('Arial', 16))
login_button.grid(row=7, column=0, pady=(20, 20), columnspan=2)

# Creating an invisible message label to display validation messages

invs_message_label = ttk.Label(root, text='', background='white')
invs_message_label.grid(row=8, column=0, padx=10, pady=5, columnspan=2)

#Makers the page look better

bottom_image = Image.open(r"images\under_design.png")
bottom_image = bottom_image.resize((346, 70))
bottom_image_photo = ImageTk.PhotoImage(bottom_image)
bottom_image_label = Label(root, image=bottom_image_photo,background="white")
bottom_image_label.image = bottom_image_photo
bottom_image_label.place(x=-8, y=580)


# Creating mulitple horizontal lines using a frame

Frame(root, width=245, height=3, bg='#1871ac').place(x=45, y=415)
Frame(root, width=245, height=3, bg='#1871ac').place(x=45, y=445)
Frame(root, width=245, height=3, bg='#1871ac').place(x=45, y=480)

# Start the main event loop

root.mainloop()
