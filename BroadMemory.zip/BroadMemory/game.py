#!/usr/bin/python
# -*- coding: utf-8 -*-
''' THis is the memory game where you can choose a difficulty 
and you have match 2 cards in order to gain points '''

from tkinter import Label, Button, messagebox
import tkinter as tk
import random
import time
from PIL import Image, ImageTk
import customtkinter
from functools import partial
import pygame
import subprocess
import sqlite3
import sys

# Set appearance and color theme using customtkinter module

customtkinter.set_appearance_mode('system')

# Global variables

score = 0
seconds = 0
selected = []
music = 1
fixed_timer = 0

# Connect to the SQLite database

conn = sqlite3.connect('user_score.db')
c = conn.cursor()

# Creating Database

c.execute('''CREATE TABLE IF NOT EXISTS users
                  (username TEXT PRIMARY KEY, password TEXT)'''
          )

# Add a new table for scores

c.execute('''CREATE TABLE IF NOT EXISTS scores
              (username TEXT, score INTEGER, date_time TEXT, grid_size TEXT,
              FOREIGN KEY(username) REFERENCES users(username))''')

# Commiting Changes

conn.commit()

# Closing

conn.close

cards = []
card_values = []


# Function to display the difficulty options

def play_game():
    ''' This is the first page that opens where you can play the game or go settings '''

    global play_button, quit_button, settings_button, main_menus_image, \
        sound_button, soundtext_Label, main_menus_button, \
        main_menus1_button, logo_label, current_user, button_sound, \
        stats_button

    #If the user opened this page straight away, its going to assume that the user is a 
    # guest so its give the current_user the value of GUEST
    if len(sys.argv) > 1:
    
        current_user = sys.argv[1]
    else:
        current_user = "GUEST"

    # Create and place UI elements

    logo_image = Image.open(r"images\logo2nd.png")
    logo_image = logo_image.resize((400, 80))
    logo_photo = ImageTk.PhotoImage(logo_image)
    logo_label = Label(root, image=logo_photo)
    logo_label.image = logo_photo
    logo_label.place(x=0, y=0)

    play_image = Image.open(r"images\play_button.jpg")
    play_image = play_image.resize((208, 200))
    play_photo = ImageTk.PhotoImage(play_image)
    play_button = Button(
        root,
        image=play_photo,
        command=show_difficulty_options,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    play_button.image = play_photo
    play_button.place(x=100, y=165)

    if current_user != 'GUEST':
        stats_image = Image.open(r"images\stats_button.png")
        stats_image = stats_image.resize((220, 110))
        stats_photo = ImageTk.PhotoImage(stats_image)
        stats_button = Button(
            root,
            image=stats_photo,
            highlightthickness=0,
            highlightbackground='white',
            bd=0,
            cursor='hand2',
            command=stats_page,
            )
        stats_button.image = stats_photo
        stats_button.place(x=94, y=423)
    else:
        pass

    quit_image = Image.open(r"images\exit button.png")
    quit_image = quit_image.resize((136, 125))
    quit_photo = ImageTk.PhotoImage(quit_image)
    quit_button = Button(
        root,
        image=quit_photo,
        command=root.destroy,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    quit_button.image = quit_photo
    quit_button.place(x=-5, y=530)

    main_menus_image = Image.open(r"images\main menu.png")
    main_menus_image = main_menus_image.resize((120, 120))
    main_menus_photo = ImageTk.PhotoImage(main_menus_image)
    main_menus_button = Button(
        root,
        image=main_menus_photo,
        command=clear_settings,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    main_menus_button.image = main_menus_photo
    main_menus_button.place(x=285, y=537)

    settings_image = Image.open(r"images\settings.png")
    settings_image = settings_image.resize((121, 111))
    settings_photo = ImageTk.PhotoImage(settings_image)
    settings_button = Button(
        root,
        image=settings_photo,
        command=settings,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    settings_button.image = settings_photo
    settings_button.place(x=285, y=537)


def settings():
    ''' This opens the settings page where you can log out/sign in or even play music '''

    global play_button, quit_button, difficulty_label, easydf_button, \
        harddf_button, logo_label, settings_button, harddf_button, \
        easydf_button, settings_button, main_menus_button, \
        sound_button, soundtext_Label, no_sound_button, \
        log_sign_button, signed_image, signed_Label, sign_label, \
        stats_button
    play_button.place_forget()
    settings_button.place_forget()
    if current_user != 'GUEST':
        stats_button.place_forget()
    else:
        pass

    signed_image = Image.open(r"images\sign_as_label.png")
    signed_image = signed_image.resize((120, 25))
    signed_photo = ImageTk.PhotoImage(signed_image)
    signed_Label = Label(root, image=signed_photo,
                         highlightthickness=0,
                         highlightbackground='white', bd=0)
    signed_Label.image = signed_photo
    signed_Label.place(x=100, y=84)

    sign_label = tk.Label(root, text=current_user,
                          font=('Century Gothic', 19, 'bold'),
                          fg='#344b5b', justify='center')
    sign_label.place(x=221, y=78)

    soundtext_image = Image.open(r"images\sound_text.png")
    soundtext_image = soundtext_image.resize((145, 50))
    soundtext_photo = ImageTk.PhotoImage(soundtext_image)
    soundtext_Label = Label(root, image=soundtext_photo,
                            highlightthickness=0,
                            highlightbackground='white', bd=0)
    soundtext_Label.image = soundtext_photo
    soundtext_Label.place(x=80, y=255)

    if music == 1:
        sound_image = Image.open(r"images\sound button.png")
        sound_image = sound_image.resize((100, 100))
        sound_photo = ImageTk.PhotoImage(sound_image)
        sound_button = Button(
            root,
            image=sound_photo,
            highlightthickness=0,
            highlightbackground='white',
            bd=0,
            cursor='hand2',
            command=play_music,
            )
        sound_button.image = sound_photo
        sound_button.place(x=240, y=230)
    else:
        no_sound_image = Image.open(r"images\no_music.png")
        no_sound_image = no_sound_image.resize((100, 100))
        no_sound_photo = ImageTk.PhotoImage(no_sound_image)
        no_sound_button = Button(
            root,
            image=no_sound_photo,
            highlightthickness=0,
            highlightbackground='white',
            bd=0,
            cursor='hand2',
            command=stop_music,
            )
        no_sound_button.image = no_sound_photo
        no_sound_button.place(x=240, y=230)

    log_sign_image = Image.open(r"images\logout_signin.png")
    log_sign_image = log_sign_image.resize((250, 125))
    log_sign_photo = ImageTk.PhotoImage(log_sign_image)
    log_sign_button = Button(
        root,
        image=log_sign_photo,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        command=logout_signin,
        )
    log_sign_button.image = log_sign_photo
    log_sign_button.place(x=80, y=340)


def logout_signin():
    ''' If the user wants to log out/sign in they will be sent to the login page'''

    subprocess.Popen(['python', r"login.py"])
    root.destroy()


def clear_settings():
    ''' when they are on the settings page and they click the main_menu butto
    n they will be sent the first page where the play button is'''

    global sound_button, soundtext_Label, main_menus_button, \
        no_sound_button, log_sign_button, signed_Label, sign_label

    soundtext_Label.place_forget()
    if music == 1:
        sound_button.place_forget()
    else:

        no_sound_button.place_forget()
    log_sign_button.place_forget()
    logo_label.place_forget()
    signed_Label.place_forget()
    sign_label.place_forget()
    main_menus_button.place_forget()
    play_game()


def play_music():
    ''' This is where the music starts and will be kept on a loop until further notice'''

    global music, no_sound_button, sound_button

    pygame.mixer.init()
    pygame.mixer.music.load(r"sound\Subway Surfers Theme Sound Effect.mp3"
                            )
    pygame.mixer.music.play(-1)  # -1 means the music will loop indefinitely
    music = 0
    no_sound_image = Image.open(r"images\no_music.png")
    no_sound_image = no_sound_image.resize((100, 100))
    no_sound_photo = ImageTk.PhotoImage(no_sound_image)
    no_sound_button = Button(
        root,
        image=no_sound_photo,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        command=stop_music,
        )
    no_sound_button.image = no_sound_photo
    no_sound_button.place(x=240, y=230)
    sound_button.place_forget()


def stop_music():
    ''' This is where the user decides to turn off the music/sound '''

    global music, sound_button, no_sound_button

    pygame.mixer.music.stop()
    music = 1
    sound_image = Image.open(r"images\sound button.png")
    sound_image = sound_image.resize((100, 100))
    sound_photo = ImageTk.PhotoImage(sound_image)
    sound_button = Button(
        root,
        image=sound_photo,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        command=play_music,
        )
    sound_button.image = sound_photo
    sound_button.place(x=240, y=230)
    no_sound_button.place_forget()


def show_difficulty_options():
    ''' This page is where you can choose a difficulty between 
    easy or hard where easy is a 4 by 4 grid and hard is a 6 by 6 gird'''

    global play_button, quit_button, difficulty_label, easydf_button, \
        harddf_button, logo_label, settings_button, harddf_button, \
        easydf_button, settings_button, main_menus_button, \
        main_menus1_button, stats_button

    play_button.place_forget()
    settings_button.place_forget()
    main_menus_button.place_forget()
    if current_user != 'GUEST':

        stats_button.place_forget()
    else:
        pass

    easydf_image = Image.open(r"images\easy.jpg")
    easydf_image = easydf_image.resize((240, 120))
    easydf_photo = ImageTk.PhotoImage(easydf_image)
    easydf_button = Button(
        root,
        image=easydf_photo,
        command=partial(start_game, 4),
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    easydf_button.image = easydf_photo
    easydf_button.place(x=80, y=200)

    harddf_image = Image.open(r"images\hard.jpg")
    harddf_image = harddf_image.resize((240, 120))
    harddf_photo = ImageTk.PhotoImage(harddf_image)
    harddf_button = Button(
        root,
        image=harddf_photo,
        command=partial(start_game, 6),
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    harddf_button.image = harddf_photo
    harddf_button.place(x=80, y=350)

    main_menus1_image = Image.open(r"images\main menu.png")
    main_menus1_image = main_menus1_image.resize((120, 120))
    main_menus1_photo = ImageTk.PhotoImage(main_menus1_image)
    main_menus1_button = Button(
        root,
        image=main_menus1_photo,
        command=clear_settings2,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    main_menus1_button.image = main_menus1_photo
    main_menus1_button.place(x=285, y=537)


def clear_settings2():
    ''' This def function is to go back to the first page
      from the page where tou can choose your difficulty '''

    global easydf_button, harddf_button, main_menus1_button

    easydf_button.place_forget()
    harddf_button.place_forget()
    main_menus1_button.place_forget()
    logo_label.place_forget()
    play_game()


def start_game(grid_size):
    ''' This is where the memory game is about to start after 
    choosing your difficulty option'''

    global difficulty_label, harddf_button, easydf_button, score, \
        seconds, selected, time_operate, score_label, timer_label, \
        board_frame, new_game_button, main_menus_button, logo_label, \
        board_remover, score_time_Label, time_operate, size_grid

    easydf_button.place_forget()
    harddf_button.place_forget()
    logo_label.place_forget()

    main_menus1_button.place_forget()
    main_menus2_image = Image.open(r"images\main menu.png")
    main_menus2_image = main_menus2_image.resize((120, 120))
    main_menus2_photo = ImageTk.PhotoImage(main_menus2_image)
    main_menus2_button = Button(
        root,
        image=main_menus2_photo,
        command=clear_settings3,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    main_menus2_button.image = main_menus2_photo
    main_menus2_button.place(x=285, y=537)

    if grid_size == 4:
        size_grid = 4
    else:
        size_grid = 6
    score = 0
    seconds = 0
    board_remover = 0
    selected = []

    score_time_image = Image.open(r"images\score_time button.png")
    score_time_image = score_time_image.resize((180, 132))
    score_time_photo = ImageTk.PhotoImage(score_time_image)
    score_time_Label = Label(root, image=score_time_photo,
                             highlightthickness=0,
                             highlightbackground='white', bd=0)
    score_time_Label.image = score_time_photo
    score_time_Label.place(x=107, y=-5)

    score_label = tk.Label(
        root,
        text='Score: 0',
        font=('Century Gothic', 13, 'underline', 'bold'),
        fg='white',
        justify='center',
        background='#344b5b',
        )
    score_label.place(x=165, y=20)

    timer_label = tk.Label(
        root,
        text='Time: 0s',
        font=('Century Gothic', 13, 'underline', 'bold'),
        fg='white',
        justify='center',
        background='#344b5b',
        )
    timer_label.place(x=165, y=45)
    board_frame = tk.Frame(root)
    board_frame.grid(row=3, column=0, columnspan=grid_size, pady=10)

    new_game_image = Image.open(r"images\Newgame.png")
    new_game_image = new_game_image.resize((168, 84))
    new_game_photo = ImageTk.PhotoImage(new_game_image)
    new_game_button = Button(
        root,
        image=new_game_photo,
        command=partial(new_game, grid_size),
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    new_game_button.image = new_game_photo
    new_game_button.place(x=120, y=517)


# Function to start a new game with a given grid size

def new_game(grid_size):
    ''' This def function activites the timer and starts the game.
      many boxes will appear depending on 
    what grid size the user picked and while be
      able pick them and try to matched the boxes that a hidden. 
    This will be timed and the score will be tracked'''

    global score, seconds, selected, time_operate, score_label, \
        timer_label, board_frame, cards, card_values, board_remover, \
        card_button, game_ender, matched_cards, fixed_timer

    # Update game variables
    
    game_ender = 0
    score = 0
    seconds = 0
    time_operate = False
    board_remover = 2
    selected = []
    fixed_timer += 1

    # Update score and timer labels

    score_label.config(text='Score: {}'.format(score))
    timer_label.config(text='Time: {}s'.format(seconds))

    if grid_size == 4:
        x_value = 35
        y_value = 125
    else:
        x_value = 25
        y_value = 130

    # Create a frame for the game board

    frame = tk.Frame(root)
    frame.place(x=x_value, y=y_value)

    board_frame = tk.Frame(frame)
    board_frame.grid(row=3, column=0, columnspan=grid_size)

    cards = []  # List to store card buttons
    matched_cards = []

    symbols = [
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R'
        ]
    card_values = symbols[:grid_size * grid_size // 2] * 2
    random.shuffle(card_values)

    # Determine button dimensions based on grid size

    if grid_size == 4:
        button_width = 5
        button_width = int(button_width)
        button_height = 2
        button_height = int(button_height)
    else:
        button_width = 3
        button_width = int(button_width)
        button_height = 1
        button_height = int(button_height)

    # Create card buttons and add them to the board frame

    for i in range(grid_size):
        for j in range(grid_size):
            card_button = tk.Button(
                board_frame,
                text='',
                width=button_width,
                height=button_height,
                relief='raised',
                command=partial(card_switch, i, j, grid_size),
                background='#9e005d',
                bd=0,
                cursor='hand2',
                foreground='white',
                border=3,
                font=('Century Gothic', 15, 'bold'),
                )
            card_button.grid(row=i, column=j, padx=5, pady=5)
            cards.append(card_button)


# Function to clear game settings and reset the UI

def clear_settings3():
    ''' You will get sent to the first page (play_game page) after clicking 
    main memu from the page where the memory game is being played'''

    global difficulty_label, harddf_button, easydf_button, score, \
        seconds, selected, time_operate, score_label, timer_label, \
        board_frame, new_game_button, main_menus2_button, logo_label, \
        board_frame, score_time_Label

    # Hide UI elements

    score_time_Label.place_forget()
    score_label.place_forget()
    timer_label.place_forget()
    new_game_button.place_forget()

    # Clear the game board if board_remover > 0

    if board_remover > 0:
        board_frame.grid_forget()
    else:
        pass

    logo_label.place_forget()

    # Display difficulty options

    play_game()


# Function to handle card button click and logic

def card_switch(i, j, grid_size):
    ''' This def function is activated when 2 boxes have been clicked 
    to check if they match or not, points may get added or not.'''

    global time_operate, score, selected, card_values, cards, \
        card_button, main_menus2_button, game_ender, seconds, \
        matched_cards

    # Start the timer if it's not already running

    if not time_operate:
        time_operate = True
        start_timer()

    # If the card is already selected, do nothing
    
    if (i, j) in selected or (i * grid_size + j) in matched_cards:
        return
    
    # Get the card button and reveal its value

    card_button = cards[i * grid_size + j]
    card_button.config(text=str(card_values[i * grid_size + j]))

    # Add the card to the selected list

    selected.append((i, j))

    # If two cards are selected, check for a match

    if len(selected) == 2:
        (box1_i, box1_j) = selected[0]
        (box2_i, box2_j) = selected[1]

        if card_values[box1_i * grid_size + box1_j] \
            == card_values[box2_i * grid_size + box2_j]:

            # Matching cards found

            if grid_size == 4:
                if seconds >= 0 and seconds <= 10:
                    score += 100
                    game_ender += 1
                elif seconds >= 11 and seconds <= 20:
                    score += 80
                    game_ender += 1
                elif seconds >= 21 and seconds <= 30:
                    score += 60
                    game_ender += 1
                elif seconds >= 31 and seconds <= 40:
                    score += 40
                    game_ender += 1
                elif seconds >= 41 and seconds <= 50:
                    score += 20
                    game_ender += 1
                elif seconds >= 51:
                    score += 10
                    game_ender += 1
            else:
                if seconds >= 0 and seconds <= 20:
                    score += 100
                elif seconds >= 21 and seconds <= 40:
                    score += 80
                elif seconds >= 41 and seconds <= 60:
                    score += 60
                elif seconds >= 61 and seconds <= 80:
                    score += 40
                elif seconds >= 81 and seconds <= 100:
                    score += 20
                elif seconds >= 101 and seconds <= 130:
                    score += 10
                elif seconds >= 131:
                    score += 5

            score_label.configure(text='Score: {}'.format(score))
            matched_cards.extend(selected)
            selected = []

            if game_ender / 2 == grid_size:
                end_game()  # All cards matched, end the game
        else:

            # No match, reset the selected cards after a delay

            root.after(1000, reset_selection, grid_size)
            for button in cards:
                button.config(state=tk.DISABLED,
                              disabledforeground='white')
            
            new_game_button.config(state=tk.DISABLED)
            root.after(1000, enable_buttons) 
            # After 1 second, re-enable the card buttons

            root.after(1000, enable_buttons)


def enable_buttons():
    ''' The def function above also disabled the other buttons 
    so the user can not break the game, 
    after a few seconds every single card that was disabedl
      should now be enabled so the user can match other cards.'''

    # Re-enable all card buttons

    for button in cards:
        button.config(state=tk.NORMAL, disabledforeground='white')
    new_game_button.config(state=tk.NORMAL)

     

# Function to reset the selected cards after a delay

def reset_selection(grid_size):
    ''' This def function puts all teh boxed with text hidden and 
    hidden again so that the user can find the matching cards.'''

    global selected, cards

     # Re-enable the button after 1000 milliseconds (1 second)
 

    

    (box1_i, box1_j) = selected[0]
    (box2_i, box2_j) = selected[1]

    # Reset the text of the selected cards to hide them

    cards[box1_i * grid_size + box1_j].configure(text='')
    cards[box2_i * grid_size + box2_j].configure(text='')

    selected = []  # Clear the selected cards list


def start_timer():
    ''' This is where the timer starts when the game is activated '''

    global seconds, timer_label, time_operate, main_menus2_button,fixed_timer

    seconds += 1
    timer_label.configure(text='Time: {}s'.format(seconds))
    timer_label.after((1000 *  fixed_timer), start_timer)


def end_game():
    ''' When all cards have been matched the game ends'''

    global time_operate, seconds, current_user

    time_operate = False

    messagebox.showinfo('Congratulations!',
                        'You won in {} seconds'.format(seconds))


    # Display scores for the current user

def back_main_page():
    ''' back button from the page where you can see your score'''

    global back_button, difficulty_option, score_frame, scrollbar, \
        logo_stats_label
    back_button.place_forget()
    play_game()
    frame_name.place_forget()
    logo_stats_label.place_forget()


def stats_page():
    ''' This page is where you can see the past scores on what grid
      size you did it on and what time you did it.
      This allows to see your score and how much you got  '''

    global play_button, quit_button, settings_button, main_menus_image, \
        sound_button, soundtext_Label, main_menus_button, \
        main_menus1_button, logo_label, current_user, button_sound, \
        stats_button, back_button, logo_stats_label
    play_button.place_forget()
    settings_button.place_forget()
    logo_label.place_forget()

    logo_stats_image = Image.open(r"images\logo2nd.png")
    logo_stats_image = logo_stats_image.resize((400, 80))
    logo_stats_photo = ImageTk.PhotoImage(logo_stats_image)
    logo_stats_label = Label(root, image=logo_stats_photo)
    logo_stats_label.image = logo_stats_photo
    logo_stats_label.place(x=0, y=0)

    if current_user != 'GUEST':

        stats_button.place_forget()
    else:
        pass
    main_menus_button.place_forget()

    back_image = Image.open(r"images\back_button.png")
    back_image = back_image.resize((115, 115))
    back_photo = ImageTk.PhotoImage(back_image)
    back_button = Button(
        root,
        image=back_photo,
        command=back_main_page,
        highlightthickness=0,
        highlightbackground='white',
        bd=0,
        cursor='hand2',
        )
    back_button.image = back_photo
    back_button.place(x=285, y=537)

    if current_user != 'GUEST' and score > 0:

        # Save the score to the database

        c.execute('INSERT INTO scores (username, score, date_time, grid_size) VALUES (?, ?, ?, ?)'
                  , (current_user, score, time.strftime('%Y-%m-%d %H:%M'
                  ), size_grid))
        conn.commit()

    if current_user != 'GUEST':
        display_scores(current_user)


    



def display_scores(username):
    ''' This def function is how it takes the information in the
      database and displays it for users to see '''
    global frame_name

    

    # Retrieve scores from the database for the given username
    c.execute("SELECT * FROM scores WHERE username=?", (username,))
    scores = c.fetchall()
    
    frame_name = customtkinter.CTkScrollableFrame(root, label_text="User: " + current_user,
                                                   width=350,height=350,fg_color="#344b5b",corner_radius=10)
    frame_name.place(x=13,y=95)
    
    if len(scores) == 0:
        no_score_label = customtkinter.CTkLabel(frame_name, text="   WELCOME TO THE MEMORY GAME!!!\n\n     HOW TO PLAY: \n  First the player turns over 2 cards.    "
                                                "       \nIf the pictures match, the player keeps \nthe cards and tries again for another match."
                                                 "     \nIf they do not match the cards are turned \nover again and must keep going "
                                                 "     \nuntil 2 cards are matched. The player must\n try to remember where they have"
                                                  "     \nseen cards, so they can \nuse them to make a match.",
                                                 font=('Century Gothic', 14, 'bold'), fg_color="#344b5b")
        no_score_label.pack(pady=5)
    else:
       
       
        for row in scores:
            score_label = customtkinter.CTkLabel(frame_name, text=f"Score: {row[1]}, Grid Size: {row[3]}, Date and Time: {row[2]}",
                                                font=('Century Gothic', 11, 'bold'), fg_color="#344b5b",  anchor="nw")
            score_label.pack(pady=5)


        

if __name__ == "__main__":
    '''This starts the programs and loops it  '''
    root = tk.Tk()
    root.geometry("400x650")

    play_game()
  
    root.resizable(False,False)
    root.mainloop()