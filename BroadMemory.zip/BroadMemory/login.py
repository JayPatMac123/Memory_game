#!/usr/bin/python
# -*- coding: utf-8 -*-
# Import necessary modules

''' This page is where user can login with thier creditials'''

import customtkinter
from PIL import Image, ImageTk
from tkinter import Tk, PhotoImage, Label, Entry, Frame, Button
from tkinter import ttk
import subprocess
import sqlite3
from PIL import Image, ImageTk

# Create a SQLite database for user scores

conn = sqlite3.connect('user_score.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users
                  (username TEXT PRIMARY KEY, password TEXT)'''
          )
conn.commit()
conn.close

# Create the main root window

root = Tk()
root.option_add('*Font', 'Arial')
root.configure(bg='white')
root.title('Create Account')
root.geometry('315x550')
root.resizable(False, False)
customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')


# Function to open the account creation window

def open_file():
    ''' This function is when the user wants to create an account '''

    subprocess.Popen(['python', r"create.py"])
    root.destroy()


# Function to hide a label (used for error messages)

def hide_label():
    ''' This hides the label for telling them, if thier information is incorrect '''

    message_label.grid_remove()


# Function to run the memory game

def run_memory_game():
    ''' If they want to play as an guest, they will have to click a 
    button and then it runs the game and leaving the login page '''

    current_user = 'GUEST'
    subprocess.call(['python', r"game.py", current_user])
    root.destroy()


# Function to register the user when the "Sign in" button is clicked

def login():
    ''' This def function checks if the user entered into the widget 
    matched the information/matches in the database '''

    username = username_entry.get()
    password = password_entry.get()

    # Connect to the SQLite database

    conn = sqlite3.connect('user_score.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE username=? AND password=?'
                   , (username, password))
    user = cursor.fetchone()

    if user:
        current_user = username
        subprocess.call(['python', r"game.py", current_user])
        root.destroy()
    else:
        message_label = ttk.Label(root,
                                  text='Invalid Username or Password',
                                  foreground='red', background='white',
                                  font=('Arial', 12, 'bold'))
        message_label.grid(row=9, column=0, padx=10, pady=5,
                           columnspan=2)
        root.after(2000, hide_label)

    conn.close()


# Load and display logo image

logo_image = PhotoImage(file=r"images\origin_logo.png")
logo_label = Label(root, image=logo_image, background='white',
                   anchor='center')
logo_label.grid(row=0, column=0, padx=10, pady=10, columnspan=2)

# Load and display an account image

account = PhotoImage(file=r"images\loginiamge.png")
account_label = Label(root, image=account, background='white')
account_label.grid(row=1, column=0, padx=10, pady=(10, 50),
                   columnspan=2)

# Label for signing in

clickhere = ttk.Label(root, text='Sign in to Continue.',
                      font=customtkinter.CTkFont(size=12, weight='bold'
                      ), foreground='#384e63', background='white')
clickhere.place(x=90, y=230)

# Username label and entry field

username_label = ttk.Label(root, text='Username:', foreground='#384e63'
                           , background='white', font=('Georgia', 13,
                           'bold'))
username_label.grid(row=3, column=0, pady=5)
username_entry = Entry(
    root,
    width=20,
    relief='flat',
    font=('Century Gothic', 13, 'bold'),
    fg='#000000',
    bg='white',
    )
username_entry.grid(row=3, column=1, pady=5)

# Horizontal lines for visual separation

Frame(root, width=200, height=2, bg='#384e63').place(x=105, y=352)
Frame(root, width=200, height=2, bg='#384e63').place(x=105, y=312)

# Password label and entry field

password_label = ttk.Label(root, text='Password:', foreground='#384e63'
                           , background='white', font=('Georgia', 13,
                           'bold'))
password_label.grid(row=5, column=0, pady=5)
password_entry = Entry(
    root,
    show='*',
    width=20,
    relief='flat',
    font=('Century Gothic', 13, 'bold'),
    fg='#000000',
    bg='white',
    )
password_entry.grid(row=5, column=1, pady=5)

# Create the "Sign in" button

login = customtkinter.CTkButton(root, text='Sign in',
                                font=customtkinter.CTkFont(family='Kaiti'
                                , size=16), text_color='white',
                                command=login)
login.grid(row=7, column=0, padx=10, pady=10, columnspan=2)

# Create "Continue as Guest" button

guest = customtkinter.CTkButton(
    root,
    text='Continue as Guest',
    font=customtkinter.CTkFont(family='Kaiti', size=16),
    text_color='white',
    width=200,
    command=run_memory_game,
    )
guest.grid(row=8, column=0, padx=10, pady=10, columnspan=2)

# Display a label to show registration status or error messages

message_label = ttk.Label(
    root,
    text='',
    foreground='red',
    background='white',
    font=('Arial', 12, 'bold'),
    border=20,
    )
message_label.grid(row=9, column=0, padx=10, pady=5, columnspan=2)

# Create the "Create Account" button

account_creation_image = Image.open(r"images\create_account_button.png")
account_creation_image = account_creation_image.resize((209, 60))
account_creation_photo = ImageTk.PhotoImage(account_creation_image)
account_creation_button = Button(
    root,
    image=account_creation_photo,
    command=open_file,
    highlightthickness=0,
    highlightbackground='white',
    bd=0,
    cursor='hand2',
    background='white',
    )
account_creation_button.image = account_creation_photo
account_creation_button.place(x=50, y=470)

# Start the main event loop

root.mainloop()
